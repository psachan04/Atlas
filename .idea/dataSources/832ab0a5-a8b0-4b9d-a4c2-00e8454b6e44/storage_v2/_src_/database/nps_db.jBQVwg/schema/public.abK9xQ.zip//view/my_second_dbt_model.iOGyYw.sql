create view my_second_dbt_model(id) as
SELECT id
FROM my_first_dbt_model
WHERE id = 1;

alter table my_second_dbt_model
    owner to atlas_admin;

